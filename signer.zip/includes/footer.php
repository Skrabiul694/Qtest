<footer>
	<p class="text-right"><?php echo date("Y"); ?> &copy; <?php echo $systemName; ?> | All Rights Reserved.</p>
</footer>