<?php
/**
 * File name: AppHelper.php
 * Last modified: 27/11/21, 5:54 PM
 * Author: NearCraft - https://codecanyon.net/user/nearcraft
 * Copyright (c) 2021
 */

namespace App\Helpers;

class AppHelper
{
    /**
     * Check license
     *
     * @return bool
     */
    public function checkLicense()
    {
        return true;
    }
}
